import{V as a,b3 as m}from"./index-BklDWftz.js";const s=o=>a(o).locale(m()).fromNow();export{s as f};
