import{d as t,bv as r}from"./index-CvtbhWKk.js";const o=({children:e})=>t(r,{get children(){return[e," - MetaCubeXD"]}});export{o as D};
